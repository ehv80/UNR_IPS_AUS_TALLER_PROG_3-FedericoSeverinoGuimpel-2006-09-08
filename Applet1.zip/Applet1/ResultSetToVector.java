import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

public class ResultSetToVector {
	static Vector transform(ResultSet r) {
		Vector datos = new Vector();
		Vector temp;

		try {
			ResultSetMetaData rs = r.getMetaData();
			while (r.next()) {
				temp = new Vector();
				for(int i=1; i<=rs.getColumnCount(); i++) {
					temp.add(r.getObject(i));
				}
				datos.addElement(temp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return datos;
	}
	
	static Vector getNames(ResultSet r) {
		Vector nombresColumnas = new Vector();
		try {
			ResultSetMetaData rs = r.getMetaData();
			for(int i=1; i <= rs.getColumnCount(); i++) {
				nombresColumnas.add(rs.getColumnName(i));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return nombresColumnas;
	}
}
